import sys
import os
import math
import random

import pygame
import pytmx


SCREEN_SIZE = WIDTH, HEIGHT = 720, 480
FIELD_WIDTH, FIELD_HEIGHT = 20, 20
MAPS_DIR = './data/maps'


def load_map(map_id):
    map_img = pygame.image.load('data/maps/' + map_id + '.png')
    map_data = []
    enemy_count = 0
    for y in range(map_img.get_height()):
        for x in range(map_img.get_width()):
            c = map_img.get_at((x, y))
            if c[1] == 100:
                map_data.append({'type': 'grass', 'pos': [x, y], 'h_pos': 400, 'enemy': False})
            if c[1] == 255:
                map_data.append({'type': 'bush', 'pos': [x, y], 'h_pos': 400, 'enemy': False})
            if c[2] == 100:
                map_data.append({'type': 'rock', 'pos': [x, y], 'h_pos': 400, 'enemy': False})
            if c[2] == 255:
                map_data.append({'type': 'box', 'pos': [x, y], 'h_pos': 400, 'enemy': False})
            if c[0] == 255:
                spawn = [x, y]
            if c[0] == 100:
                map_data[-1]['enemy'] = True
                enemy_count += 1
    return map_data, spawn, enemy_count


pygame.init()
screen = pygame.display.set_mode((920, 680), 0, 32)
clock = pygame.time.Clock()

all_sprites = pygame.sprite.Group()
enemies_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
box_group = pygame.sprite.Group()
tiles = [[[0] * (FIELD_WIDTH + 1) for __ in range(FIELD_HEIGHT + 1)] for _ in range(3)]


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def terminate():
    pygame.quit()
    sys.exit()


FPS = 60


def start_screen(screen, clock):
    fon = pygame.transform.scale(load_image('fon.jpg'), SCREEN_SIZE)
    screen.blit(fon, (0, 0))
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                return
            pygame.display.flip()
            clock.tick(FPS)


class Field:
    # free_tiles, finidh_tiles
    def __init__(self, filename):
        self.map = pytmx.load_pygame(f'{MAPS_DIR}/{filename}')
        self.height = self.map.height
        self.width = self.map.width
        self.tile_size = self.map.tilewidth
        #self.free_tiles = free_tiles
        #self.finish_tiles = finidh_tiles

    def render(self, screen):
        for y in range(self.height):
            for x in range(self.width):
                image = self.map.get_tile_image(x, y, 0)
                screen.blit(image, (x * self.tile_size, y * self.tile_size))

    def get_tile_id(self, position):
        return self.map.tiledgidmap[self.map.get_tile_gid(*position, 0)]


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, list_of_frames, x, y):
        super().__init__(all_sprites)
        self.frames = list_of_frames
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = pygame.Rect(x, y, self.frames[self.cur_frame].get_width(),
                                self.frames[self.cur_frame].get_height())
        self.rect = self.rect.move(x, y)

    def update(self):
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]

    def change_frame(self, list_of_frames):
        self.frames = list_of_frames
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]


sword_im = pygame.transform.scale(load_image('saber.png'), (116, 16))


class Angle:
    def __init__(self):
        self.degrees = 0
        self.sin = 0
        self.cos = 1
        self.hyp = 0

    def change(self, mx, my, pos):
        self.hyp = math.sqrt((mx - pos[0]) ** 2 + (my - pos[1]) ** 2)
        if self.hyp:
            self.cos = (mx - pos[0]) / self.hyp
            self.sin = (-my + pos[1]) / self.hyp
            self.degrees = math.degrees(math.atan2(self.sin, self.cos))


mainAngle = Angle()


class Hero(AnimatedSprite):
    im_1 = pygame.transform.scale(load_image('explorer_run1.png'), (40, 60))
    im_2 = pygame.transform.scale(load_image('explorer_run2.png'), (40, 60))
    idle = pygame.transform.scale(load_image('explorer_idle.png'), (40, 60))

    def __init__(self, pos_x, pos_y):
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.update_ = False
        self.idle_frame = [Hero.idle]
        self.flip = False
        self.progress = 0
        self.speed = 0
        super().__init__([Hero.im_1, Hero.im_2], pos_x, pos_y)

    def advance(self):
        cos, sin = mainAngle.cos, mainAngle.sin
        if cos < 0 and not self.flip or cos > 0 and self.flip:
            self.flip = not self.flip
            self.frames = [pygame.transform.flip(self.frames[0], True, False),
                           pygame.transform.flip(self.frames[1], True, False)]
            self.idle_frame = [pygame.transform.flip(Hero.idle, True, False)]
        self.pos_x += int(max(1, abs(cos * self.speed)) * (1 if cos > 0 else -1))
        self.pos_y -= int(max(1, abs(sin * self.speed)) * (1 if sin > 0 else -1))
        self.rect.x = self.pos_x
        self.rect.y = self.pos_y

    def update(self):
        if mainAngle.hyp:
            super().update()
            self.cur_frame = int(self.progress) % len(self.frames)
            self.image = self.frames[self.cur_frame]
        else:
            self.frames = self.idle_frame

    def change_frame(self, amount):
        self.cur_frame += amount
        self.progress = (self.cur_frame + 1) / len(self.frames)


class Cursor(pygame.sprite.Sprite):
    image = pygame.transform.scale(load_image('cursor.png'), (32, 32))

    def __init__(self, abcissa, ordinate, *group):
        super().__init__(*group)
        self.image = Cursor.image
        self.rect = self.image.get_rect()
        self.rect.x = abcissa
        self.rect.y = ordinate
        self.hide = False

    def update(self, abcissa, ordinate):
        self.rect.x = abcissa
        self.rect.y = ordinate


def main():
    field = Field('level1.tmx')
    level = 1
    tile_width = field.tile_size
    spawn = {
        1: (30, 4)
    }
    true_game_scroll = [spawn[level][0] * tile_width - spawn[level][1] * tile_width - screen.get_width() // 2,
                        spawn[level][0] * tile_width + spawn[level][1] * tile_width - screen.get_height() // 2]
    game_scroll = [true_game_scroll[0], true_game_scroll[1]]
    cursor_sprite = Cursor(0, 0)
    frame_offset = 0
    pygame.mouse.set_visible(False)

    start_screen(screen, clock)
    screen.fill((0, 0, 0))
    running = True
    hero = Hero(*spawn[level])
    player_group.add(hero)

    background_offset = 0

    while running:
        mx, my = pygame.mouse.get_pos()
        mainAngle.change(mx, my, (hero.pos_x, hero.pos_y))
        background_offset = (background_offset + 0.25) % 30
        for i in range(9):
            pygame.draw.line(screen, (5, 18, 24), (-10, int(i * 30 + background_offset - 20)),
                             (screen.get_width() + 10, int(i * 30 - 110 + background_offset)), 15)

    #
        game_mx = ((mx + game_scroll[0]) + (my + game_scroll[1])) / 18 * 100
        game_my = ((-mx - game_scroll[0]) + (my + game_scroll[1])) / 18 * 100

        player_offset_x = game_mx - 30 - hero.rect.x
        player_offset_y = game_my + 60 - hero.rect.y

        hero.speed = min(1, max(0, mainAngle.hyp - 100) / 150)
        hero.speed **= 2
        hero.speed *= 10

        player_render_x = (hero.rect.x - hero.rect.y) / 100 * 9
        player_render_y = (hero.rect.x + hero.rect.y) / 100 * 9
        true_game_scroll[0] -= (true_game_scroll[0] + screen.get_width() // 2 - player_render_x) / 50
        true_game_scroll[1] -= (true_game_scroll[1] + screen.get_height() // 2 - (player_render_y)) / 50
    #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEMOTION:
                cursor_sprite.update(*event.pos)
            # Buttons
            if event.type == pygame.KEYDOWN:
                pass

        # Moving
        print(mainAngle.hyp)
        if mainAngle.hyp:
            hero.advance()

        print(hero.speed)

        hero.change_frame(int(hero.speed / 2) + 3)

        # Rendering

        clock.tick(60)
        screen.fill((0, 0, 0))
        field.render(screen)
        all_sprites.update()
        all_sprites.draw(screen)
        screen.blit(cursor_sprite.image, cursor_sprite.rect)

        rotated_sword_im = pygame.transform.rotate(sword_im, math.degrees(math.atan2(mainAngle.sin, mainAngle.cos)))
        pos = (hero.rect.x + hero.image.get_width() // 2, int(hero.rect.y + hero.image.get_height() * 2 / 3))
        screen.blit(rotated_sword_im, rotated_sword_im.get_rect(center=pos))

        if hero.speed >= 8:
            frame_offset += (15 - frame_offset) / 20
        else:
            frame_offset += (-frame_offset) / 50

        pygame.draw.rect(screen, (5, 18, 24),
                         pygame.Rect(0, screen.get_height() - frame_offset, screen.get_width(), 15))
        pygame.draw.rect(screen, (5, 18, 24), pygame.Rect(0, -15 + frame_offset, screen.get_width(), 15))
        pygame.display.flip()
    pygame.quit()


main()
